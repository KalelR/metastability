# A neurodynamical model for working memory

Author: Pascanu
Date: 2011
Definition classification: Variability in phase-space
Exp Theo Definition: implicit
Imp Theo Definition: as the switching between attractors, discusses the mechanims ". Departing
from the classical notion of attractors, a number of alternative
‘‘attractor-like’’ metastability phenomena have been considered"
Mechanism: Very nice refernece!
Priority: Medium