# Large-scale cortical travelling waves predict localized future cortical signals

Author: David M. Alexander
Date: 2019
Definition classification: N/A
Priority: Medium