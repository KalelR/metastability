# Metastable neural dynamics in Alzheimer's disease are disrupted by lesions to the
structural connectome

Author: Alderson
Date: 2018
Definition classification: Variability of synchronization
Degree of metastability: std(R)
Exp Theo Definition: The number or repertoire of such channels therefore corresponds to the variability of these phase relationships (i.e. the metastability) measured as the standard deviation of RRSN
Measurement: fMRI
Priority: Low
TL;DR: Brief review of other papers I read