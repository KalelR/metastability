# Metastable brain waves

Author: Roberts
Date: 2019
Definition classification: Variability in states
Degree of metastability: N/A
Details: Patterns do recurr, but that is not a criteria for metastability; transition between metastable states marked by a disorganized period of reconfiguration
Exp Theo Definition: a form of winnerless competition whereby the system’s orbits visit multiple patterns in sequence and no single pattern endures
Experimental apparatus: Simulation
Imp Theo Definition: switching between different patterns/states (wave patterns).
Measurement: Waves: mean potential of pyramidal cells
Mechanism: Cite heteroclinic cycle and chaotic itinerancy; differentiates from multistability with noise
Priority: High
Scales - Analysis: Spatial macroscopic, Spatial microscopic, Topological mesoscopic
Simulation model: Neural mass
TL;DR: TL;DR: Simulam whole-brain usando neural mass models. Encontram ondas nos campos medios de regioes. Veem varios padroes de ondas, que mudam ao longo do tempo mesmo para parametros fixos. Esse sequential swithching é chamado de metastabilidade. Observam que transições metastaveis ocorrem por colisao, aniquilaçao ou criaçao de novas fontes ou sumidouros nas ondas. Diziem que isso entao propoe uma unificaçao sobre entendimento de metastabilidade e ondas. Encaram metastabilidade como variabilidade nos padrões da rede, mas não quantificam ela. Dizem que é uma forma de winnerless competition e distinguem de multiestabilidade.