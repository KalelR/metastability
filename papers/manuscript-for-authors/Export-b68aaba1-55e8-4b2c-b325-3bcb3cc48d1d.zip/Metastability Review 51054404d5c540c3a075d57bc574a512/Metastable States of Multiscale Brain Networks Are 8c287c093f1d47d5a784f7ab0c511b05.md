# Metastable States of Multiscale Brain Networks Are Keys to Crack the Timing Problem

Author: Gili
Date: 2018
Definition classification: Physics energy
Exp Theo Definition: states that transiently attract the dynamics; energy landscape
Priority: Low