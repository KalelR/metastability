# Spin-glass model predicts metastable brain states that
diminish in anesthesia

Author: Hudetz
Date: 2014