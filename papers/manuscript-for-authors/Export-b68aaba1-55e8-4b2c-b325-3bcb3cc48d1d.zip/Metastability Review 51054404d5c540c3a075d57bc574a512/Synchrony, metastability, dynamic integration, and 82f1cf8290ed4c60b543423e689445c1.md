# Synchrony, metastability, dynamic integration, and competition in thespontaneous functional connectivity of the human brain

Author: Wens
Date: 2019
Priority: Very low