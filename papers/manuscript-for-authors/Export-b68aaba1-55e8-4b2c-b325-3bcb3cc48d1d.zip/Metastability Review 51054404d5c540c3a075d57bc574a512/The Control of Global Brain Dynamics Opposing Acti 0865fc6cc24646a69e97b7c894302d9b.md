# The Control of Global Brain Dynamics: Opposing Actions of
Frontoparietal Control and Default Mode Networks on
Attention

Author: Hellyer
Date: 2014
Definition classification: Variability of synchronization
Degree of metastability: std(V), V a degree of coherence == sync error
Exp Theo Definition: metastability, which we define as the extent to which synchrony
varies over time;
Metastability, which we here define as the tendency to move endogenously between transient attractor-like states, is an important property of such systems
Priority: Medium