# Resting-State Temporal Synchronization Networks Emerge from Connectivity Topology and Heterogeneity

Author: Ponce-Alvarez
Date: 2015
Definition classification: Variability of synchronization
Degree of metastability: N/A
Details: Metastability underlies the transient formation of synchronized clusters; also implements integration-segregation naturally; metastability requires heterogeneity and modular topology; Metastability important as it it "facilitates the exploration of a larger dynamical repertoire of the brain and allows for the all- around visitation of functional states and dynamic responses to the external world."
Exp Theo Definition: N/A
Experimental apparatus: fMRI (bold, n = 66 regions)
Imp Prac Def: Changes in relative phases of nodes
Imp Theo Definition: Regime between unsynchronized and synchronized
Measurement: hilbert → phases → phase differences (pdf); R; clusters
calculate clusters of synchronized neurons
Mechanism: N/A; region between unsynchronized and synchronized
Priority: High
Results: maximum metastability at transition to phase synchronization; We found that fluctuations in the global synchronization result from intermittent activation of synchronized communities
Scales - Analysis: Spatial macroscopic, Topological macroscopic, Topological mesoscopic
Scales - Definition: N/A
Simulation model: Kuramoto, slow oscillators