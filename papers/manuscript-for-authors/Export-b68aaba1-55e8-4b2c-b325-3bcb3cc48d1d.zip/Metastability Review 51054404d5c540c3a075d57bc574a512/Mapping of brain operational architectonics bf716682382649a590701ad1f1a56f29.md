# Mapping of brain operational architectonics

Author: Fingelkurts
Date: 2004
Definition classification: Integration-Segregation
Details: Metastability is seen as the mechanism/regime responsible for this I~S tendency. Since this tendency produces the cognitive/behavioral processes, metastability can thus be said to be responsible for the operations in the brain. Furthermore, the processes are constituted by sucession of discrete acts, each of which can be called a (metastable) state.; 
Synchronization binds neurons into assemblies, whose coordination is responsible for behavior. Their synchronized operataions constitute the metastable spatial-temporal patterns observed.
Exp Theo Definition: Metastability: regime in which each specialized cortical area performs a unique role by expressing its own form of information and at the same time its performance is largely constrained by interactions with other areas to which it is functionally connected; where the individual parts of the brain exhibit tendencies to function autonomously at the same time as they exhibit tendencies for coordinated activity.
Measurement: EEG / MEG
Mechanism: Aparentemente, falam em algum paper que metastabilidade é due to intrninsic dynamics, n estimulo externo
Priority: High
Scales - Analysis: Spatial macroscopic, Topological macroscopic, Topological mesoscopic