# Role of local network oscillations in resting-state functional connectivity.

Author: Cabral
Date: 2011
Priority: Low
Results: variability in global synchronization related to metastable cluster synchronization (according do Deco, 2016)