# Attractor Landscapes and Active Tracking: The Neurodynamics of Embodied Action

Author: Negrello
Date: 2008
Definition classification: N/A
Exp Theo Definition: implicit
Imp Theo Definition: they do not explicitly discuss metastability, but discuss how changing inputs over time changes the attractors and the trajectories along with it; talk about transients and how the system is at a constant transient (which they cal meta-transient)
Priority: High