# Extended Neural Metastability in an Embodied Model of Sensorimotor Coupling

Author: Aguilera
Date: 2016
Definition classification: Physics transient stable
Priority: High
Status: REREAD