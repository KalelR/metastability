# Working Memory and Anticipatory Set Modulate Midbrain
and Putamen Activity

Author: Yu
Date: 2013
Definition classification: Physics energy
Exp Theo Definition: implicit
Imp Theo Definition: move from a transiently attracting region
"To enable flexible representation, a relatively flat energy landscape is required, such that the system can move easily from one
metastable attractor state to another (Durstewitz et al., 2000)"
Priority: Low