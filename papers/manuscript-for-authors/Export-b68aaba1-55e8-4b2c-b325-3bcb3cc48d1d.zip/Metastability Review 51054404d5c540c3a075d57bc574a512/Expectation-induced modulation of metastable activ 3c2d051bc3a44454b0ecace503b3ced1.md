# Expectation-induced modulation of metastable activity underlies faster coding of sensory stimuli

Author: La Camera
Date: 2019
Priority: Low