# Metastability and chimera states in modular delay and pulse-coupled oscillator networks

Author: Wildie & Shanahan
Date: 2012
Definition classification: Variability of synchronization
Degree of metastability: <std(R)_c>: average over communities of the variance of their phase synchronization; also calculate variety of metastable states (coalition entropy)
Details: Deco, 2016 cita esse quando fala sobre variability in phase configurations over time
Exp Theo Definition: metastability of the system as the variance in individual community synchrony.
Measurement: Kuramoto phase → R
Mechanism: N/A
Priority: High
Results: Maximum metastability at transition between desynchronization and global synchronization due to increase in delay (though not necessarily in transitions due to increase in p_ext).
High coalition entropy (number of coalitions) at transition due to delay also.
Modular topology increases this maximum: randomized versions still have the maximum, but much lower, so that the curve is closer to a line.;
OBserve chimera sattes, with some communities synchronized, and others not.
Scales - Analysis: Spatial microscopic, Topological mesoscopic
Simulation model: Kuramoto with delay and modular topology