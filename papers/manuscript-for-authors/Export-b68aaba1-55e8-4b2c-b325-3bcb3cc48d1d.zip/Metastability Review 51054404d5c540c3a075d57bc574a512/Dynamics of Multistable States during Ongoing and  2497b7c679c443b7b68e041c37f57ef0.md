# Dynamics of Multistable States during Ongoing and Evoked
Cortical Activity

Author: Mazzucato
Date: 2015
Definition classification: Variability in states
Degree of metastability: only in absolute
Exp Theo Definition: N/A
Imp Theo Definition: metastability as a sequence of metastable states
transition seem abrupt, but they do not mention this in the implicit definition
Measurement: electrophysiological ; simulations → states (hmm)
Priority: Medium
Results: Spiking network replicates lots of behaviors
See transitions between states (defined from the neurons' firing rates)
Transition appear abrupt, but they don't talk too much about it
network hopping between metastable states in which different combinations of clusters are simultaneously activated