# An Intermittency Mechanism for Coherent and Flexible Brain and Behavioral Function

Author: Kelso
Date: 1991
Priority: Low