# Dynamic functional connectivity and brain metastability during altered states of consciousness

Author: Cavanna
Date: 2017
Definition classification: Variability in phase-space, Variability in states
Details: Dynamic core/theories of consciousness
Exp Theo Definition: Metastability: phenomenon of the system's dynamics traversing a series of metastable states (points in phase-space of quasi-equilibrium that transiently attract the dynamics);
Quasi-equilibrium points in phase-space "are also termed metastable states of the system, with the phenomenon of the dynamics traversing a series of such states being called metastability."
Mechanism: We note that different mechanisms exist capable of trapping the
dynamics in certain parts of the phase space, such as attractor ruins
(Kaneko and Tsuda, 2003), heteroclinic cycles (Rabinovich et al., 2008),
and unstable attractors (Timme et al., 2002);
Distinguishes from multistability with noise. Says that metastability does not revolve aroudn points of stability (only quasi-stability), while multistability+noise does.
metastability appears "instead as the result of the opposing tendency of the dynamics
towards coupling and independence"
Priority: Very High
Results: Discuss models of consciousness and their behavior regarding the repertoire of possible brain configurations. See metastable dynamics as a "plausible way in which such a repertoire of brain configurations could emerge"
Scales - Definition: Discuss how the variables of the phase space depend on the scales being considered;