# Cortical computations via metastable activity

Author: La Camera
Date: 2019
Definition classification: Variability in states
Degree of metastability: only in absolute
Details: Clustered topology apparently necessary for the metastable dynamics
Exp Theo Definition: the sequence of discrete, quasi-stationary metastable states, with abrupt, jump-like transitions between them; Contrasts this with chaotic dynamics, where transitions are "continuous"
Experimental apparatus: Hidden Markov Model
Measurement: electrophysiological, others?
Mechanism: Metastable activity occurs both in response to an external stimulus and during ongoing, self-generated activity.
multistability with noise: Metastable activity naturally occurs when multiple hidden states are attractive fixed points of the neural dynamics which are either inherently unstable, or can be destabilized by internal noise or external perturbations
Such fixed points would attract the dynamic trajectories of the neural activity and force them to linger in their neighborhood for a finite amount of time. It is natural, therefore, to look for models wherein metastability is caused by the coexistence of multiple attractor states
Priority: High
Results: "ensemble activity unfolds as a sequence of metastable states, each lasting from a few hundred ms to a second or more, with sharp transitions among the states"
The transi- tions are typically one order of magnitude faster than the state durations, are close to their theoretically observable lower bound, and are not an artifact of the HMM
states tend to reoccur
The clustered archi tecture has emerged as an effective way to generate metastability.
A arquitetura faz com que: multiple configurations of the network emerge wherein neurons in clusters tend to occupy several states with different values of mean firing rates (grey and red lines in Figure 3b), where the firing rates depend on the number of active clusters.
Simulation model: Clustered network of LIF; 
TL;DR: TL;DR: Revisa literatura de metastabilidade estudada com hidden markov models. Define metastability as the sequence of discrete, quasi-stationary metastable states, with abrupt, jump-like transitions between them. These transitions are one order of magnitude slower than the duration of the states. Contrasts this with chaotic dynamics, where transitions are "continuous". Reviews studies of metastability which use Hidden Markov Models. Explains this methodology. Review importance of this metastability. Says a reasonable mechanism is multistability with noise, and says that spiking neural neworks appear to need a clustered architecture to have this metastable dynamics.