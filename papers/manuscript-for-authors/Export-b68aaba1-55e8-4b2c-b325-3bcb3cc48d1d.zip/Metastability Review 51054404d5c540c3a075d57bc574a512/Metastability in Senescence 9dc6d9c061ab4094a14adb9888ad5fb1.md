# Metastability in Senescence

Author: Naik
Date: 2017
Definition classification: CD: Outside equilibrium state, Variability in states, Variability of synchronization
Degree of metastability: std(R)
Exp Theo Definition: metastability: a theoretical framework that gives a systematic account of the variability of the brain.
Metastable systems: a dynamic system that falls outside a natural equilibrium state but can persist there for an extended period of time.
Metastability: quantifiable measure of a dynamic system of coupled oscillators. It is defined here as the standard deviation of the Kuramoto
Priority: Very low