# Metastable Resting State Brain Dynamics

Author: beim Graben
Date: 2019
Definition classification: Variability in phase-space, Variability in states
Degree of metastability: ???
Exp Theo Definition: "Metastability refers to the fact that the state of a dynamical system spends a large amount of time in a restricted region of its available phase space before a transition takes place, bringing the system into another state from where it might recur into the previous one.". Também se referem a estados metastáveis como transient and recurrent states.
describe switching between the metastable states
Measurement: fMRI bold
Mechanism: 3 mechanisms: multiple-timescale (one attractor); riddle-basins (multistable with noise); heteroclinic cycle
Priority: High
Results: find maximum metastability in some regions, but i don't know what that means