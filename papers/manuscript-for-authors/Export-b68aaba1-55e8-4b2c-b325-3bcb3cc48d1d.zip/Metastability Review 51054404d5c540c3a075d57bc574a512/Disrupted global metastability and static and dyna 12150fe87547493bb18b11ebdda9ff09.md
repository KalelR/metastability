# Disrupted global metastability and static and dynamic brain connectivity across individuals in the Alzheimer’s disease continuum

Author: Cordova-Palomera
Date: 2017
Definition classification: Variability of synchronization
Degree of metastability: std(R)
Exp Theo Definition: phase-based metrics of
coupling and de-coupling across time: metastability (
"A wide range (large standard deviation) of Kuramoto order parameter values would thus characterize brains that traverse different dynamic stages of coupling over time: a broad set of dynamic states, measured as high metastability."
Imp Theo Definition: Metastable state: one that attracts transiently (To enable flexible representation, a relatively flat energy landscape is required, such that the system can move easily from one
metastable attractor state to another (Durstewitz et al., 2000))
Priority: Low
Scales - Definition: global