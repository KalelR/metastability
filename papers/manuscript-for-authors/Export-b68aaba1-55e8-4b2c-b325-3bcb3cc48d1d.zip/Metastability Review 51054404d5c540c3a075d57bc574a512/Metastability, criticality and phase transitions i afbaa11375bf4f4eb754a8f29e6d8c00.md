# Metastability, criticality and phase transitions in brain and its models

Author: Werner
Date: 2007
Definition classification: Integration-Segregation, Variability in phase-space
Exp Theo Definition: "shifts and transitions between stable states"; "meandering of the systems representation in phase space";
"a continuous scale of tendencies for neural groups to coordinate and segregate seems more appropriate"
Priority: High