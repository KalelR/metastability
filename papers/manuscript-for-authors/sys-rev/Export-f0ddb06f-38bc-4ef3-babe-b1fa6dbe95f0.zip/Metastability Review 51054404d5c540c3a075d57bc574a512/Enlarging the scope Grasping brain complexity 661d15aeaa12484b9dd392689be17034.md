# Enlarging the scope: Grasping brain complexity

Author: Tognoli
Citation: tognoli_2014a
Date: 2014
Degree of metastability: N/A
Exp Theo Definition: incomplete synchronization tendencies, realization of integration and segregation; mechanism for integration and segregatio
Measurement: N/A
Mechanism: N/A
Results: "typically arises when the parts are no longer perfect clones of one another"
Scales - Definition: Say that micro to macro have integration-segregation tendencies
Simulation model: N/A