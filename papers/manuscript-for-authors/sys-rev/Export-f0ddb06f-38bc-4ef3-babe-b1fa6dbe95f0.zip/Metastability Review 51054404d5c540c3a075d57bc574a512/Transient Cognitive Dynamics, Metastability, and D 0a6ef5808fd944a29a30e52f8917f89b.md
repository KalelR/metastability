# Transient Cognitive Dynamics, Metastability, and Decision Making

Author: Rabinovich
Date: 2018