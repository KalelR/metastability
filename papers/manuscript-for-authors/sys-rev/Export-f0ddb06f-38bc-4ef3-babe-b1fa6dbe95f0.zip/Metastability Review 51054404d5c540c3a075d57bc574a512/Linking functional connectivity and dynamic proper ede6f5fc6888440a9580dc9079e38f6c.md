# Linking functional connectivity and dynamic properties of resting-state networks

Author: Lee
Date: 2017
Degree of metastability: std(R)
Exp Prac Def: N/A
Exp Theo Definition: Degree of variability in networks states over time, realization of integration and segregation; mechanism for integration and segregatio
Experimental apparatus: fMRI
Imp Prac Def: N/A
Imp Theo Definition: N/A
Measurement: hilbert → R → std(R)
Mechanism: intermittency of synchronization
Results: maximum metastability at transition to phase synchronization; increased metastability and synchrony were associated with elevated cohesion and decreased functional integration
Scales - Analysis: Spatial macroscopic, Topological macroscopic
Scales - Definition: Variable
Simulation model: Kuramoto