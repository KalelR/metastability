# The labile brain. II. Transients, complexity and selection

Author: Friston
Citation: friston_2000a
Date: 2000
Degree of metastability: entropy of spectral densities
Exp Theo Definition: synonym of complexity and dynamic instability: successive expression of different transient dynamics with stereotyped temporal patterns being continuously created and destroyed and re-emerging again,transient periods of stability
Measurement: LFP; Consequently the changeability or stability of the spectral densities can be used to measure metastability.
Mechanism: Separates in two: due to dynamics and due to change in parameters. Dynamics is likened to intermittency and apparent change in the manifold that is due to the itinerant nature of the trajectory getting stuck in local submanifolds;
See more discussion on wiki
Priority: Very High
Results: fala do efeito de aumentar o acoplamento: de incoerente, pra metastavel, pra phase-locked (nessa rede).; dynamic instability is evident only in a limited regime of connection strengths, namely when they are sparse.
Scales - Analysis: Spatial macroscopic, Topological macroscopic
TL;DR: TLDR: Fala que dynamic instability (ie instabilidade do ponto de vista dinamico do sistema), metastabilidade e complexidade são sinonimos. Define-os como "successive expression of different transient dynamics with stereotyped temporal patterns being continuously created and destroyed and re-emerging again". Em seguida, define tipos diferentes de complexidade, dependendo se a variaçao da dinamica vem de o atrator ser intermitente ou de variaçao nos parametros de controle. Define de novo a ideia dele de que em metastabilidade vc tem um atrator, que aparenta ser varios subatratores. Em seguida, define uma medida de metastabilidade, baseado na entropia da densidade espectral (do LFP, acho). Mede isso para uma rede e encontra que metastabilidade é encontrada quando a conectividade é esparsa e na transieçao para sincronizaçao. Nesse sentido, fala que para baixo acoplamento tem comportamento incoerente, daí metastavel e daí phase-locked. Fala que justamente esses regimes (de metastabilidade==dynamic instability) são encontrados em regiões perto de pontos críticos ou transições de fase, e isso é consiste com o "pensamento moderno sobre systemas auto-organizados". Termina falando sobre selection e coisas sobre o cerebro que podem ser importantes (nao entendi)