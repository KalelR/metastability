# Global segregation of cortical activity and metastable dynamics

Priority: Very low