# Signature of consciousness in the dynamics of resting-state brain activity

Author: Barttfeld
Date: 2015