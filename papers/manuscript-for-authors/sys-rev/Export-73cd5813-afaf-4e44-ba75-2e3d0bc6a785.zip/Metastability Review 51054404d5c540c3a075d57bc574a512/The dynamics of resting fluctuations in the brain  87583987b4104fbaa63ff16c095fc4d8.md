# The dynamics of resting fluctuations in the brain: metastability and its dynamical cortical core

Author: Deco
Date: 2017
Degree of metastability: std(R)
Details: look at topological micro, but for dynamic core analysis, not metastability!; Metastability is maximum at the working point of the model; they say it is reflecting the variability of the synchronization between different nodes, i.e. the fluctuations of the states of phase configurations as a function of
time
Exp Theo Definition: Coordination dynamics: metastability refers to a coupled or collective oscillatory activity which falls outside its equilibrium state for dwell times that depend on distance from equilibrium,variability of global synchronization,variability of the states of phase configurations; how the synchronization between the different nodes fluctuates across time
Experimental apparatus: fMRI (bold)
Measurement: hilbert→phases → R → std(R)
Mechanism: variety of mechanisms; Example of metastable dynamical system is winnerless competition
Priority: High
Scales - Analysis: Spatial macroscopic, Topological macroscopic, Topological microscopic
Simulation model: Hopf model, fitted on experimental FC