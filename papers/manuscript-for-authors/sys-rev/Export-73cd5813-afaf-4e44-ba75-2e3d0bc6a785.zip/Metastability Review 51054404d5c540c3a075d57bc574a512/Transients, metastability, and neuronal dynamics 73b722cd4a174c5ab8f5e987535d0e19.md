# Transients, metastability, and neuronal dynamics

Author: Friston
Date: 1997
Degree of metastability: entropy of spectral densities; Intuitively it can be seen that a large spectral density
attractor ‘‘covers’’ more regions and reflects a greater
number and diversity of transients (i.e., metastability).
A measure of the volume of the spectral density attrac-
tor is provided by the entropy H
Details: Importancia integraçao-segregação; diz que atractor global com subatratores parece ser o jeito de pensar em neuronal dynamics
Exp Theo Definition: recurrent and self-limiting expression of stereotyped transient-like dynamics,succession of transient-like dynamics each with its own distinct and recurring spatiotemporal organiza- tion,{We have framed metastability in terms of the successive expression of transients that emerge when simulated neuronal populations are loosely coupled or sparsely connected. The term ‘‘transient’’ is used here to denote a distinct self-limiting stereotyped pattern of activity.
Mechanism: fixed global attractor, with trajectory visiting different submanifolds; ie This phenomenon can be understood in terms of a complex attractor surface that traps the trajectory locally in some ‘‘sub- manifold’’ before it escapes to another locally struc- tured part of the attractor surface. These submanifolds are exactly the same as a normal attractor manifold but for the fact that they are connected to, or embedded in, a larger surface. At some point the trajectory will find this connection and a new transient will emerge as the trajectory moves off to another submanifold.
Priority: Medium
Results: Mostra que com aumento do eps sistema passa de incoerencia estavel (cada parte mantendo a sua tendencia oscilatoria individual) para regime de metastabilidade (com transientes e periodos de coerencia estavel, que sao na vdd instaveis) para, finalmente, phase locking.; On the basis of this, and in the light of the
simulations presented above, we infer that neuronal
dynamics are modeled by neither an ensemble of sepa-
rate attractors nor a simple low-dimensional attractor,
but are consistent with the attractor surface that
ensues when many separate attractors are loosely
coupled together. This manifold has a special complex-
ity, where the trajectories upon it show complicated
metastable dynamics, with the recurrent appearance
and destruction of transient-like dynamics
Scales - Analysis: Spatial macroscopic, Topological macroscopic