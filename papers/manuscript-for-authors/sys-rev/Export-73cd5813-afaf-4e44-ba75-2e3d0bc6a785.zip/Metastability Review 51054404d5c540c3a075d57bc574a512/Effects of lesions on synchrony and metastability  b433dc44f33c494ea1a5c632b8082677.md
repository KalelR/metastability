# Effects of lesions on synchrony and metastability in cortical networks

Author: Vasa
Date: 2015
Degree of metastability: global: std(R); neighbourhood: std(R_neigh)
Exp Theo Definition: spontaneously shifting between transient attractor-like states; dynamical flexibility
Measurement: phase→R→std(R); neighbourhood of the lesioned nodes
Priority: Low
Scales - Analysis: Topological macroscopic, Topological mesoscopic
Simulation model: Kuramoto, fittex to experimental