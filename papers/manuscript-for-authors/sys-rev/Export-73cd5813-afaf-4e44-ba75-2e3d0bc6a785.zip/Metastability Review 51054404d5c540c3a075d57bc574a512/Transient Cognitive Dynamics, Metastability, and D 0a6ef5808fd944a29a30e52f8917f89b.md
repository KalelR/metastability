# Transient Cognitive Dynamics, Metastability, and Decision Making

Author: Rabinovich
Date: 2018
Degree of metastability: N/A
Details: Describe the heteroclinic cycle, and say that que um sistema com isso consegue então ser robusto a ruído (ie com transientes replicáveis), mas ainda sensível aos inputs: a topologia do SHC pode mudar, mas ele ainda continua existindo.; normal application of nonlinera dynamics may not be enough
Exp Theo Definition: N/A
Imp Theo Definition: Sucession of (metastable) states; Sequential switching between metastable states
Measurement: diz que poderia applicar principal component analysys a fMRI para construir o espaço de fase
Mechanism: stable heteroclinic cycle: saddle point connected to each other; esse é o jeito segundo eles de implementar winnerless competition: quando vencedores vao sendo substituidos por outros indefinidamente
Priority: Medium
TL;DR: TL;DR: Traz uma visão sobre metastabilidade: uma cadeia de atratores-sela (cada atrator-sela é um estado metastável). Os links dessa cadeia são separatrizes (variedades instaveis/estaveis?). O sistema transita assim ao longo da cadeia, que pode acabar num atrator ou ser repetitiva (eg formando um ciclo-limite). A cadeia é chamada de heteroclinic skeleton, com as trajetorias proximas chamadas de stable heteroclinic channel (SHC). Nesse caso, a metastabilidade se dá pela transição sucessiva dos atratores-sela. Dizem que um sistema com isso consegue então ser robusto a ruído (ie com transientes replicáveis), mas ainda sensível aos inputs: a topologia do SHC pode mudar, mas ele ainda continua existindo.
Propoe uma soluçao para um modelo para sequential decision making como um jogo a tempo fixo em que o jogador deve tomar decisões num ambiente com ruído para maximizar a recompensa cumulativa. Esse trabalho é uma sequel de vários outros tratando redes desse tipo como redes com winnerless competition. Nesse caso, veja (Winnerless competition principle and prediction of the transient dynamicsin a Lotka–Volterra model): winnerless competition ocorre quando há sucessão de vários winners, que eles modelam como um sistema metastável.
obs: cita trabalhos talvez importantes sobre competiçao e metastabilidade no cerebro; diz que aplicaçao normal de dinamica nao-linear nao é suficiente.