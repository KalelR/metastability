# Metastability of Neuronal Dynamics during General Anesthesia: Time for a Change in Our Assumptions?

Author: Hudson
Date: 2017
Degree of metastability: (implicit): Only in absolute
Exp Theo Definition: jumping between several different attractors with multipled well-separated time-scales.; Metastable systems will spend most of their time near attractors, with rare, rapid transitions between them.
Priority: High
Scales - Definition: Dwell time in a metastate has to be long; rapid transitions between