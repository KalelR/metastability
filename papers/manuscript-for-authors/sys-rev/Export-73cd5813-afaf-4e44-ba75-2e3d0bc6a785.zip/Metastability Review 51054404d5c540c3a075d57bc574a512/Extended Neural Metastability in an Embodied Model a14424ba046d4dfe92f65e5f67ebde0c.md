# Extended Neural Metastability in an Embodied Model of Sensorimotor Coupling

Author: Aguilera
Date: 2016
Priority: High