# Metastable neural dynamics underlies cognitive performance across multiple behavioural paradigms

Author: Alderson
Date: 2020
Degree of metastability: std(R); call it global metastability
Details: integration~segregation
metastability at rest corresponds to an optimal exploration of the dynamical repertoire inherent in the static structural linkages of the anatomy where the probability of network switching is maximal
Exp Prac Def: The
350 maintenance of a particular communication channel through coherence implies a
persistent phase relationship. The number or repertoire of such channels therefore
corresponds to the variability of these phase relationships (i.e. the metastability)
Exp Theo Definition: Coordination dynamics: metastability refers to a coupled or collective oscillatory activity which falls outside its equilibrium state for dwell times that depend on distance from equilibrium
Imp Theo Definition: Metastability as dynamic flexibility, or variability of network states over time
Measurement: hilbert→phases → R → std(R)
Mechanism: variety of mechanisms; Example of metastable dynamical system is winnerless competition
Priority: High
Results: Overall, we found that–contrary to expectations–the metastabil- ity of couplings between large-scale networks was actively enhanced by task performance, principally in regions known to be devoted to cognitive control. Although metastability was evoked by task, cogni- tive performance was more closely aligned with the metastability of the brain's intrinsic network dynamics.
Scales - Analysis: Spatial macroscopic, Topological macroscopic